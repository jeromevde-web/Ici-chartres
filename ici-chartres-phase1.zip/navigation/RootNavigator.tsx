import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

import { AgendaScreen } from '../screens/AgendaScreen';
import { ExploreScreen } from '../screens/ExploreScreen';
import { FavoritesScreen } from '../screens/FavoritesScreen';
import { HomeScreen } from '../screens/HomeScreen';
import { ProfileScreen } from '../screens/ProfileScreen';
import type { RootTabParamList } from '../types/navigation';
import { colors, typography } from '../constants/theme';

const Tab = createBottomTabNavigator<RootTabParamList>();

type IconName = keyof typeof Ionicons.glyphMap;

const TAB_ICONS: Record<keyof RootTabParamList, { active: IconName; inactive: IconName }> = {
  Accueil: { active: 'home', inactive: 'home-outline' },
  Explorer: { active: 'compass', inactive: 'compass-outline' },
  Agenda: { active: 'calendar', inactive: 'calendar-outline' },
  Favoris: { active: 'heart', inactive: 'heart-outline' },
  Profil: { active: 'person', inactive: 'person-outline' },
};

/**
 * Navigation principale (5 onglets), stylée avec les tokens du
 * design system. Le contenu de chaque écran reste un placeholder
 * pour cette phase.
 */
export function RootNavigator() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerTitleAlign: 'center',
          headerTitleStyle: { ...typography.h3, color: colors.textPrimary },
          headerStyle: { backgroundColor: colors.background },
          tabBarActiveTintColor: colors.primary,
          tabBarInactiveTintColor: colors.textMuted,
          tabBarStyle: {
            backgroundColor: colors.surface,
            borderTopColor: colors.border,
            height: 64,
            paddingTop: 6,
            paddingBottom: 10,
          },
          tabBarLabelStyle: { ...typography.caption },
          tabBarIcon: ({ focused, color, size }) => {
            const icons = TAB_ICONS[route.name as keyof RootTabParamList];
            return (
              <Ionicons name={focused ? icons.active : icons.inactive} size={size} color={color} />
            );
          },
        })}
      >
        <Tab.Screen name="Accueil" component={HomeScreen} />
        <Tab.Screen name="Explorer" component={ExploreScreen} />
        <Tab.Screen name="Agenda" component={AgendaScreen} />
        <Tab.Screen name="Favoris" component={FavoritesScreen} />
        <Tab.Screen name="Profil" component={ProfileScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
