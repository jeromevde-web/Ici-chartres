/**
 * Liste des onglets principaux de l'application.
 * Toute nouvelle route de la tab bar doit être ajoutée ici.
 */
export type RootTabParamList = {
  Accueil: undefined;
  Explorer: undefined;
  Agenda: undefined;
  Favoris: undefined;
  Profil: undefined;
};
