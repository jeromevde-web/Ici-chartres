import { StyleSheet, Text, View } from 'react-native';

import { colors, spacing, typography } from '../constants/theme';

type PlaceholderScreenProps = {
  title: string;
};

/**
 * Écran de remplacement générique pour les phases 0-1.
 * Sert aussi de vérification visuelle rapide des tokens du
 * design system (couleurs, typographie, espacements).
 * Sera remplacé écran par écran dans les phases suivantes
 * (Accueil en Phase 3, Explorer en Phase 4, etc.).
 */
export function PlaceholderScreen({ title }: PlaceholderScreenProps) {
  return (
    <View style={styles.container}>
      <Text style={[typography.h1, styles.title]}>{title}</Text>
      <Text style={[typography.body, styles.subtitle]}>Écran à construire</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.background,
    gap: spacing.xs,
  },
  title: {
    color: colors.textPrimary,
  },
  subtitle: {
    color: colors.textSecondary,
  },
});
