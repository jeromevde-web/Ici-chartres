import { StyleSheet, Text, View } from 'react-native';

import { colors, radius, spacing, typography } from '../../constants/theme';

export type BadgeVariant = 'success' | 'danger' | 'info' | 'deal' | 'accent' | 'neutral';

export type BadgeProps = {
  label: string;
  variant?: BadgeVariant;
};

const VARIANT_STYLES: Record<BadgeVariant, { background: string; text: string }> = {
  success: { background: colors.secondaryLight, text: colors.success },
  danger: { background: colors.accentLight, text: colors.danger },
  info: { background: colors.primaryLight, text: colors.primary },
  deal: { background: colors.dealLight, text: colors.dealDark },
  accent: { background: colors.accentLight, text: colors.accentDark },
  neutral: { background: colors.grayLight, text: colors.textSecondary },
};

/**
 * Badge d'état court (ex: "Ouvert", "Gratuit", "Bon plan").
 * Usages courants :
 * - success  -> "Ouvert", "Gratuit"
 * - danger   -> "Fermé"
 * - deal     -> "Bon plan"
 * - accent   -> "Nouveau"
 * - info     -> "À venir"
 */
export function Badge({ label, variant = 'neutral' }: BadgeProps) {
  const { background, text } = VARIANT_STYLES[variant];

  return (
    <View style={[styles.container, { backgroundColor: background }]}>
      <Text style={[typography.caption, { color: text }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignSelf: 'flex-start',
    paddingHorizontal: spacing.sm,
    paddingVertical: 3,
    borderRadius: radius.pill,
  },
});
