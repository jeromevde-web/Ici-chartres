import { Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { colors, radius, sizes } from '../../constants/theme';

export type FavoriteButtonProps = {
  isFavorite: boolean;
  disabled?: boolean;
  onPress?: () => void;
};

/**
 * Bouton favori (composant visuel uniquement pour cette phase —
 * la persistance Supabase sera branchée plus tard).
 */
export function FavoriteButton({ isFavorite, disabled, onPress }: FavoriteButtonProps) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      accessibilityState={{ selected: isFavorite, disabled: !!disabled }}
      accessibilityLabel={isFavorite ? 'Retirer des favoris' : 'Ajouter aux favoris'}
      style={[styles.container, disabled && styles.disabled]}
      hitSlop={8}
    >
      <Ionicons
        name={isFavorite ? 'heart' : 'heart-outline'}
        size={sizes.icon.lg}
        color={isFavorite ? colors.accent : colors.textSecondary}
      />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    width: sizes.touchTarget,
    height: sizes.touchTarget,
    borderRadius: radius.pill,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
  },
  disabled: {
    opacity: 0.4,
  },
});
