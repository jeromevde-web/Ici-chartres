import { Pressable, StyleSheet, Text } from 'react-native';

import { colors, radius, spacing, typography } from '../../constants/theme';

export type FilterChipProps = {
  label: string;
  selected?: boolean;
  disabled?: boolean;
  onPress?: () => void;
};

/**
 * Chip de filtre horizontal (ex: barre de filtres d'Explorer ou
 * de l'Agenda : "Tout", "Manger", "Sortir"...).
 */
export function FilterChip({ label, selected, disabled, onPress }: FilterChipProps) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      accessibilityState={{ selected: !!selected, disabled: !!disabled }}
      style={[
        styles.container,
        selected && styles.containerSelected,
        disabled && styles.containerDisabled,
      ]}
    >
      <Text
        style={[
          typography.label,
          { color: selected ? colors.textInverse : colors.textPrimary },
          disabled && { color: colors.textMuted },
        ]}
      >
        {label}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: spacing.lg,
    height: 36,
    borderRadius: radius.pill,
    backgroundColor: colors.grayLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  containerSelected: {
    backgroundColor: colors.primary,
  },
  containerDisabled: {
    backgroundColor: colors.grayLight,
    opacity: 0.5,
  },
});
