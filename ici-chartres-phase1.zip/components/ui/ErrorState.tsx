import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { colors, spacing, typography } from '../../constants/theme';
import { Button } from './Button';

export type ErrorStateProps = {
  title?: string;
  description?: string;
  onRetry?: () => void;
};

/**
 * État d'erreur générique.
 * Ex : "Oups, quelque chose s'est mal passé." + "Réessayer".
 */
export function ErrorState({
  title = 'Oups, quelque chose s’est mal passé.',
  description,
  onRetry,
}: ErrorStateProps) {
  return (
    <View style={styles.container}>
      <View style={styles.iconWrapper}>
        <Ionicons name="alert-circle-outline" size={40} color={colors.danger} />
      </View>
      <Text style={[typography.h3, styles.title]}>{title}</Text>
      {description ? (
        <Text style={[typography.body, styles.description]}>{description}</Text>
      ) : null}
      {onRetry ? (
        <Button title="Réessayer" onPress={onRetry} variant="outline" style={styles.action} />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
    gap: spacing.xs,
  },
  iconWrapper: {
    width: 72,
    height: 72,
    borderRadius: 999,
    backgroundColor: colors.accentLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.md,
  },
  title: {
    color: colors.textPrimary,
    textAlign: 'center',
  },
  description: {
    color: colors.textSecondary,
    textAlign: 'center',
  },
  action: {
    marginTop: spacing.lg,
  },
});
