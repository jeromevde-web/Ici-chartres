import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { colors, radius, sizes, spacing, typography } from '../../constants/theme';

type IconName = keyof typeof Ionicons.glyphMap;

export type CategoryChipProps = {
  label: string;
  icon?: IconName;
  selected?: boolean;
  onPress?: () => void;
};

/**
 * Raccourci visuel vers une catégorie (Manger, Sortir, Culture...).
 * Utilisé notamment sur l'accueil et dans Explorer.
 */
export function CategoryChip({ label, icon, selected, onPress }: CategoryChipProps) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityState={{ selected: !!selected }}
      style={styles.wrapper}
    >
      <View style={[styles.iconCircle, selected && styles.iconCircleSelected]}>
        {icon ? (
          <Ionicons
            name={icon}
            size={sizes.icon.lg}
            color={selected ? colors.textInverse : colors.primary}
          />
        ) : null}
      </View>
      <Text
        style={[typography.caption, { color: selected ? colors.primary : colors.textSecondary }]}
        numberOfLines={1}
      >
        {label}
      </Text>
    </Pressable>
  );
}

const CIRCLE_SIZE = 56;

const styles = StyleSheet.create({
  wrapper: {
    alignItems: 'center',
    width: 72,
    gap: spacing.xs,
  },
  iconCircle: {
    width: CIRCLE_SIZE,
    height: CIRCLE_SIZE,
    borderRadius: radius.pill,
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconCircleSelected: {
    backgroundColor: colors.primary,
  },
});
