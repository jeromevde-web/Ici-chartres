import { useEffect, useState } from 'react';
import { Animated, StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';

import { colors, radius, sizes, spacing } from '../../constants/theme';

export type SkeletonProps = {
  width?: number | `${number}%`;
  height?: number;
  borderRadius?: number;
  style?: StyleProp<ViewStyle>;
};

/**
 * Bloc de chargement animé (pulsation douce).
 * Brique de base pour tous les skeletons de l'app.
 */
export function Skeleton({
  width = '100%',
  height = 16,
  borderRadius = radius.small,
  style,
}: SkeletonProps) {
  const [opacity] = useState(() => new Animated.Value(0.5));

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, { toValue: 1, duration: 650, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 0.5, duration: 650, useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [opacity]);

  return (
    <Animated.View
      style={[{ width, height, borderRadius, backgroundColor: colors.grayLight, opacity }, style]}
    />
  );
}

/** Skeleton correspondant à la mise en page de PlaceCard. */
export function PlaceCardSkeleton() {
  return (
    <View style={styles.card}>
      <Skeleton height={sizes.cardImage.height} borderRadius={radius.medium} />
      <View style={styles.cardBody}>
        <Skeleton width="70%" height={16} />
        <Skeleton width="40%" height={13} />
      </View>
    </View>
  );
}

/** Skeleton correspondant à la mise en page de EventCard. */
export function EventCardSkeleton() {
  return (
    <View style={styles.card}>
      <Skeleton height={sizes.cardImage.height} borderRadius={radius.medium} />
      <View style={styles.cardBody}>
        <Skeleton width="35%" height={12} />
        <Skeleton width="80%" height={16} />
        <Skeleton width="50%" height={13} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    width: 220,
    gap: spacing.sm,
  },
  cardBody: {
    gap: spacing.xs,
  },
});
