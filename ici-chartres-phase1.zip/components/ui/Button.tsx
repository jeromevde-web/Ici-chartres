import { forwardRef } from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
  type PressableProps,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { colors, radius, sizes, spacing, typography } from '../../constants/theme';

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md' | 'lg';

type IconName = keyof typeof Ionicons.glyphMap;

export type ButtonProps = Omit<PressableProps, 'style'> & {
  title: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  disabled?: boolean;
  loading?: boolean;
  icon?: IconName;
  style?: StyleProp<ViewStyle>;
};

const HEIGHT_BY_SIZE: Record<ButtonSize, number> = {
  sm: 36,
  md: sizes.touchTarget,
  lg: 52,
};

const PADDING_X_BY_SIZE: Record<ButtonSize, number> = {
  sm: spacing.md,
  md: spacing.lg,
  lg: spacing.xl,
};

/**
 * Bouton générique de ICI CHARTRES.
 * Toutes les couleurs/espacements viennent des tokens du design system.
 */
export const Button = forwardRef<View, ButtonProps>(function Button(
  { title, variant = 'primary', size = 'md', disabled, loading, icon, style, ...pressableProps },
  ref,
) {
  const isDisabled = disabled || loading;

  return (
    <Pressable
      ref={ref}
      accessibilityRole="button"
      accessibilityState={{ disabled: isDisabled, busy: loading }}
      disabled={isDisabled}
      style={({ pressed }) => [
        stylesForVariant(variant, isDisabled, pressed),
        { height: HEIGHT_BY_SIZE[size], paddingHorizontal: PADDING_X_BY_SIZE[size] },
        style,
      ]}
      {...pressableProps}
    >
      {loading ? (
        <ActivityIndicator color={textColorForVariant(variant)} />
      ) : (
        <View style={styles.content}>
          {icon ? (
            <Ionicons
              name={icon}
              size={sizes.icon.md}
              color={textColorForVariant(variant)}
              style={styles.icon}
            />
          ) : null}
          <Text
            style={[
              typography.label,
              { color: textColorForVariant(variant), fontSize: size === 'lg' ? 16 : 14 },
            ]}
          >
            {title}
          </Text>
        </View>
      )}
    </Pressable>
  );
});

function textColorForVariant(variant: ButtonVariant): string {
  switch (variant) {
    case 'outline':
    case 'ghost':
      return colors.primary;
    default:
      return colors.textInverse;
  }
}

function stylesForVariant(
  variant: ButtonVariant,
  disabled: boolean | undefined,
  pressed: boolean,
): StyleProp<ViewStyle> {
  const base: ViewStyle = {
    borderRadius: radius.pill,
    alignItems: 'center',
    justifyContent: 'center',
    opacity: disabled ? 0.5 : pressed ? 0.85 : 1,
  };

  switch (variant) {
    case 'primary':
      return { ...base, backgroundColor: colors.primary };
    case 'secondary':
      return { ...base, backgroundColor: colors.accent };
    case 'danger':
      return { ...base, backgroundColor: colors.danger };
    case 'outline':
      return {
        ...base,
        backgroundColor: colors.transparent,
        borderWidth: 1.5,
        borderColor: colors.primary,
      };
    case 'ghost':
      return { ...base, backgroundColor: colors.transparent };
    default:
      return base;
  }
}

const styles = StyleSheet.create({
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  icon: {
    marginRight: spacing.xs,
  },
});
