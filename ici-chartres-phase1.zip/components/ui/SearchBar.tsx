import { Pressable, StyleSheet, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { colors, radius, sizes, spacing, typography } from '../../constants/theme';

export type SearchBarProps = {
  value: string;
  onChangeText: (text: string) => void;
  onSubmit?: () => void;
  onClear?: () => void;
  placeholder?: string;
};

/**
 * Barre de recherche réutilisable. Ne contient aucune logique de
 * recherche — c'est un composant purement visuel pour cette phase.
 */
export function SearchBar({
  value,
  onChangeText,
  onSubmit,
  onClear,
  placeholder = 'Rechercher un restaurant, une sortie, une activité...',
}: SearchBarProps) {
  return (
    <View style={styles.container}>
      <Ionicons name="search" size={sizes.icon.md} color={colors.textMuted} />
      <TextInput
        value={value}
        onChangeText={onChangeText}
        onSubmitEditing={onSubmit}
        placeholder={placeholder}
        placeholderTextColor={colors.textMuted}
        style={styles.input}
        returnKeyType="search"
        accessibilityLabel="Rechercher"
      />
      {value.length > 0 && onClear ? (
        <Pressable
          onPress={onClear}
          accessibilityRole="button"
          accessibilityLabel="Effacer la recherche"
        >
          <Ionicons name="close-circle" size={sizes.icon.md} color={colors.textMuted} />
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.large,
    paddingHorizontal: spacing.md,
    height: sizes.touchTarget,
    gap: spacing.sm,
  },
  input: {
    flex: 1,
    ...typography.body,
    color: colors.textPrimary,
  },
});
