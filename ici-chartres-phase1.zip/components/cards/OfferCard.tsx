import { Image, StyleSheet, Text, View } from 'react-native';

import { colors, sizes, spacing, typography } from '../../constants/theme';
import { Badge } from '../ui/Badge';
import { Card } from './Card';

export type OfferCardProps = {
  title: string;
  placeName: string;
  discountLabel: string;
  imageUrl?: string;
  validityLabel?: string;
  onPress?: () => void;
};

/**
 * Carte "bon plan" (offre / promotion liée à un commerce).
 */
export function OfferCard({
  title,
  placeName,
  discountLabel,
  imageUrl,
  validityLabel,
  onPress,
}: OfferCardProps) {
  return (
    <Card onPress={onPress} style={styles.card}>
      <View style={styles.imageWrapper}>
        {imageUrl ? (
          <Image source={{ uri: imageUrl }} style={styles.image} />
        ) : (
          <View style={[styles.image, styles.imageFallback]} />
        )}
        <View style={styles.dealBadge}>
          <Badge label={discountLabel} variant="deal" />
        </View>
      </View>

      <View style={styles.body}>
        <Text style={[typography.h3, styles.title]} numberOfLines={1}>
          {title}
        </Text>
        <Text style={[typography.bodySmall, styles.place]} numberOfLines={1}>
          {placeName}
        </Text>
        {validityLabel ? (
          <Text style={[typography.caption, styles.validity]}>{validityLabel}</Text>
        ) : null}
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  card: {
    width: 220,
  },
  imageWrapper: {
    position: 'relative',
  },
  image: {
    width: '100%',
    height: sizes.cardImage.height,
  },
  imageFallback: {
    backgroundColor: colors.grayLight,
  },
  dealBadge: {
    position: 'absolute',
    top: spacing.sm,
    left: spacing.sm,
  },
  body: {
    padding: spacing.md,
    gap: 4,
  },
  title: {
    color: colors.textPrimary,
  },
  place: {
    color: colors.textSecondary,
  },
  validity: {
    color: colors.textMuted,
  },
});
