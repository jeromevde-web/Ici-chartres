import { Image, StyleSheet, Text, View } from 'react-native';

import { colors, sizes, spacing, typography } from '../../constants/theme';
import { Badge, type BadgeVariant } from '../ui/Badge';
import { FavoriteButton } from '../ui/FavoriteButton';
import { Card } from './Card';

export type PlaceCardProps = {
  name: string;
  category: string;
  imageUrl?: string;
  distanceLabel?: string;
  rating?: number;
  statusLabel?: string;
  statusVariant?: BadgeVariant;
  isFavorite?: boolean;
  onPress?: () => void;
  onFavoritePress?: () => void;
};

/**
 * Carte "lieu" (restaurant, café, commerce, activité...).
 * Utilisée dans Explorer, l'accueil, les favoris.
 */
export function PlaceCard({
  name,
  category,
  imageUrl,
  distanceLabel,
  rating,
  statusLabel,
  statusVariant = 'success',
  isFavorite = false,
  onPress,
  onFavoritePress,
}: PlaceCardProps) {
  return (
    <Card onPress={onPress} style={styles.card}>
      <View style={styles.imageWrapper}>
        {imageUrl ? (
          <Image source={{ uri: imageUrl }} style={styles.image} />
        ) : (
          <View style={[styles.image, styles.imageFallback]} />
        )}
        {statusLabel ? (
          <View style={styles.statusBadge}>
            <Badge label={statusLabel} variant={statusVariant} />
          </View>
        ) : null}
        <View style={styles.favoriteWrapper}>
          <FavoriteButton isFavorite={isFavorite} onPress={onFavoritePress} />
        </View>
      </View>

      <View style={styles.body}>
        <Text style={[typography.h3, styles.name]} numberOfLines={1}>
          {name}
        </Text>
        <View style={styles.metaRow}>
          <Text style={[typography.bodySmall, styles.metaText]} numberOfLines={1}>
            {category}
            {distanceLabel ? ` · ${distanceLabel}` : ''}
          </Text>
          {typeof rating === 'number' ? (
            <Text style={[typography.bodySmall, styles.rating]}>★ {rating.toFixed(1)}</Text>
          ) : null}
        </View>
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  card: {
    width: 220,
  },
  imageWrapper: {
    position: 'relative',
  },
  image: {
    width: '100%',
    height: sizes.cardImage.height,
  },
  imageFallback: {
    backgroundColor: colors.grayLight,
  },
  statusBadge: {
    position: 'absolute',
    top: spacing.sm,
    left: spacing.sm,
  },
  favoriteWrapper: {
    position: 'absolute',
    top: spacing.xs,
    right: spacing.xs,
  },
  body: {
    padding: spacing.md,
    gap: 4,
  },
  name: {
    color: colors.textPrimary,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  metaText: {
    color: colors.textSecondary,
    flexShrink: 1,
  },
  rating: {
    color: colors.deal,
    fontWeight: '600',
  },
});
