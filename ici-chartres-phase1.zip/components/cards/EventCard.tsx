import { Image, StyleSheet, Text, View } from 'react-native';

import { colors, sizes, spacing, typography } from '../../constants/theme';
import { Badge } from '../ui/Badge';
import { FavoriteButton } from '../ui/FavoriteButton';
import { Card } from './Card';

export type EventCardProps = {
  title: string;
  dateLabel: string;
  placeName: string;
  imageUrl?: string;
  isFree?: boolean;
  priceLabel?: string;
  isFavorite?: boolean;
  onPress?: () => void;
  onFavoritePress?: () => void;
};

/**
 * Carte "événement" (concert, spectacle, animation...).
 * Utilisée sur l'accueil et l'Agenda.
 */
export function EventCard({
  title,
  dateLabel,
  placeName,
  imageUrl,
  isFree,
  priceLabel,
  isFavorite = false,
  onPress,
  onFavoritePress,
}: EventCardProps) {
  return (
    <Card onPress={onPress} style={styles.card}>
      <View style={styles.imageWrapper}>
        {imageUrl ? (
          <Image source={{ uri: imageUrl }} style={styles.image} />
        ) : (
          <View style={[styles.image, styles.imageFallback]} />
        )}
        <View style={styles.favoriteWrapper}>
          <FavoriteButton isFavorite={isFavorite} onPress={onFavoritePress} />
        </View>
      </View>

      <View style={styles.body}>
        <Text style={[typography.caption, styles.date]}>{dateLabel}</Text>
        <Text style={[typography.h3, styles.title]} numberOfLines={2}>
          {title}
        </Text>
        <Text style={[typography.bodySmall, styles.place]} numberOfLines={1}>
          {placeName}
        </Text>
        {isFree ? (
          <Badge label="Gratuit" variant="success" />
        ) : priceLabel ? (
          <Text style={[typography.bodySmall, styles.price]}>{priceLabel}</Text>
        ) : null}
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  card: {
    width: 220,
  },
  imageWrapper: {
    position: 'relative',
  },
  image: {
    width: '100%',
    height: sizes.cardImage.height,
  },
  imageFallback: {
    backgroundColor: colors.grayLight,
  },
  favoriteWrapper: {
    position: 'absolute',
    top: spacing.xs,
    right: spacing.xs,
  },
  body: {
    padding: spacing.md,
    gap: 4,
  },
  date: {
    color: colors.primary,
    textTransform: 'uppercase',
  },
  title: {
    color: colors.textPrimary,
  },
  place: {
    color: colors.textSecondary,
  },
  price: {
    color: colors.textPrimary,
    fontWeight: '600',
  },
});
