import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';

import { env } from '../constants/env';

/**
 * Client Supabase unique de l'application.
 *
 * Toujours importer ce client plutôt que d'en recréer un ailleurs,
 * pour garder une seule source de vérité (session, cache, etc.).
 */
export const supabase = createClient(env.supabaseUrl, env.supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});
