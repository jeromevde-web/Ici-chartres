import { PlaceholderScreen } from '../components/PlaceholderScreen';

export function AgendaScreen() {
  return <PlaceholderScreen title="Agenda" />;
}
