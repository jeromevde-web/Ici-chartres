import { PlaceholderScreen } from '../components/PlaceholderScreen';

export function FavoritesScreen() {
  return <PlaceholderScreen title="Favoris" />;
}
