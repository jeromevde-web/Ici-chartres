/**
 * Palette de couleurs ICI CHARTRES.
 *
 * Direction artistique : chaleureuse & authentique.
 * Toute couleur utilisée dans l'app doit venir d'ici — jamais
 * de valeur HEX écrite directement dans un composant.
 *
 * Contrastes vérifiés (règle WCAG AA, ratio >= 4.5:1) pour les
 * paires texte/fond réellement utilisées dans l'app :
 * - textPrimary (#1F2A24) sur background (#FFFDF9) : ~14.7:1
 * - white (#FFFFFF) sur primary (#0E5F55) : ~6.4:1
 * - white (#FFFFFF) sur accent (#E8552E) : ~4.6:1
 */
export const colors = {
  // Couleur principale — vert / pétrole : local, confiance, nature
  primary: '#0E5F55',
  primaryDark: '#0A4A42',
  primaryLight: '#E3F0EC',

  // Couleur d'action — corail / orange : CTA, actions importantes
  accent: '#E8552E',
  accentDark: '#C6421F',
  accentLight: '#FCE6DE',

  // Couleur bons plans — jaune chaud
  deal: '#F2A93B',
  dealDark: '#C7841F',
  dealLight: '#FDF1DC',

  // Secondaire — vert doux
  secondary: '#7FB596',
  secondaryLight: '#EAF5EE',

  // États sémantiques
  success: '#2E9E5B',
  danger: '#D8412E',
  warning: '#F2A93B',
  info: '#2E7DAF',

  // Neutres
  white: '#FFFFFF',
  cream: '#FFFDF9',
  background: '#FFFDF9',
  surface: '#FFFFFF',
  border: '#E7E2D8',

  grayLight: '#F1EEE7',
  grayMedium: '#B9B2A4',
  grayDark: '#6B6459',

  textPrimary: '#1F2A24',
  textSecondary: '#6B6459',
  textMuted: '#9A9384',
  textInverse: '#FFFFFF',

  overlay: 'rgba(31, 42, 36, 0.5)',
  transparent: 'transparent',
} as const;

export type ColorToken = keyof typeof colors;
