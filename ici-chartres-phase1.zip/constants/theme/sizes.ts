/**
 * Tailles standardisées : icônes, zones tactiles, avatars.
 * `touchTarget` respecte le minimum d'accessibilité (44pt iOS
 * / 48dp Android) pour toute zone tactile.
 */
export const sizes = {
  icon: {
    sm: 16,
    md: 20,
    lg: 24,
    xl: 32,
  },
  touchTarget: 44,
  avatar: {
    sm: 32,
    md: 40,
    lg: 56,
  },
  cardImage: {
    height: 140,
  },
} as const;
