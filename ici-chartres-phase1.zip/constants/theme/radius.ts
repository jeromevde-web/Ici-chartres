/**
 * Rayons de bordure. ICI CHARTRES utilise des formes légèrement
 * arrondies, cohérentes sur toute l'app.
 */
export const radius = {
  small: 6,
  medium: 12,
  large: 18,
  xl: 24,
  pill: 999,
} as const;

export type RadiusToken = keyof typeof radius;
