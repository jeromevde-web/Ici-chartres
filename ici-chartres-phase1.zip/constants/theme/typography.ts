import { Platform, type TextStyle } from 'react-native';

/**
 * Hiérarchie typographique.
 *
 * MVP : on utilise la police système (San Francisco / Roboto)
 * plutôt qu'une police custom, pour éviter le chargement de
 * fonts et rester simple et performant. Une police de marque
 * pourra être introduite plus tard sans changer cette API.
 */
const fontFamily = Platform.select({
  ios: 'System',
  android: 'sans-serif',
  default: 'System',
});

type TypographyToken = Pick<
  TextStyle,
  'fontFamily' | 'fontSize' | 'fontWeight' | 'lineHeight' | 'letterSpacing'
>;

export const typography: Record<
  'display' | 'h1' | 'h2' | 'h3' | 'body' | 'bodySmall' | 'caption' | 'label',
  TypographyToken
> = {
  display: { fontFamily, fontSize: 32, fontWeight: '700', lineHeight: 38 },
  h1: { fontFamily, fontSize: 26, fontWeight: '700', lineHeight: 32 },
  h2: { fontFamily, fontSize: 21, fontWeight: '700', lineHeight: 27 },
  h3: { fontFamily, fontSize: 17, fontWeight: '600', lineHeight: 22 },
  body: { fontFamily, fontSize: 15, fontWeight: '400', lineHeight: 21 },
  bodySmall: { fontFamily, fontSize: 13, fontWeight: '400', lineHeight: 18 },
  caption: { fontFamily, fontSize: 12, fontWeight: '500', lineHeight: 16 },
  label: {
    fontFamily,
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 16,
    letterSpacing: 0.2,
  },
};

export type TypographyVariant = keyof typeof typography;
