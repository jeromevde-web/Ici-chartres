/**
 * Échelle d'espacement. Toujours utiliser ces tokens plutôt
 * que des valeurs arbitraires (marges, paddings, gaps).
 */
export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  '2xl': 32,
  '3xl': 48,
} as const;

export type SpacingToken = keyof typeof spacing;
