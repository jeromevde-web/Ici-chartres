/**
 * Variables d'environnement typées pour l'application.
 *
 * Expo expose automatiquement toute variable préfixée par `EXPO_PUBLIC_`
 * (définie dans `.env`) via `process.env` — aucune librairie
 * supplémentaire n'est nécessaire (Expo SDK 49+).
 *
 * Ne jamais mettre de vraies clés secrètes ici : seules les clés
 * publiques (anon key Supabase, protégée par Row Level Security)
 * doivent transiter par ce fichier.
 */

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  // En développement, on préfère un avertissement explicite à un crash
  // silencieux plus tard dans l'appli.
  console.warn(
    '[env] EXPO_PUBLIC_SUPABASE_URL ou EXPO_PUBLIC_SUPABASE_ANON_KEY manquant(e). ' +
      'Copiez .env.example vers .env et renseignez vos identifiants Supabase.',
  );
}

export const env = {
  supabaseUrl: supabaseUrl ?? '',
  supabaseAnonKey: supabaseAnonKey ?? '',
} as const;
