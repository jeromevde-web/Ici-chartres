import type { Ionicons } from '@expo/vector-icons';

type IconName = keyof typeof Ionicons.glyphMap;

/**
 * Catégories principales de ICI CHARTRES.
 *
 * NOTE : selon le master prompt, les catégories doivent à terme
 * venir de la table Supabase `categories`. Cette liste statique
 * sert uniquement de support pour construire et illustrer les
 * composants du design system (CategoryChip, etc.) en Phase 1 ;
 * elle sera remplacée par des données réelles en Phase 2/3.
 */
export const CATEGORIES: { slug: string; label: string; icon: IconName }[] = [
  { slug: 'manger', label: 'Manger', icon: 'restaurant' },
  { slug: 'sortir', label: 'Sortir', icon: 'musical-notes' },
  { slug: 'culture', label: 'Culture', icon: 'business' },
  { slug: 'activites', label: 'Activités', icon: 'bicycle' },
  { slug: 'commerces', label: 'Commerces', icon: 'bag' },
  { slug: 'services', label: 'Services', icon: 'construct' },
  { slug: 'bons-plans', label: 'Bons plans', icon: 'pricetag' },
];
